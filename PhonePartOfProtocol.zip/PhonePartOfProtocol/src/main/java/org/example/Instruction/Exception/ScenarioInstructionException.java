package org.example.Instruction.Exception;

public class ScenarioInstructionException extends Exception{

    public ScenarioInstructionException(){};
    public ScenarioInstructionException(String message){
        super(message);
    }
}
