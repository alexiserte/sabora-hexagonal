package org.example.Instruction.Exception;

public class LightInstructionException extends Exception{

    public LightInstructionException(){};
    public LightInstructionException(String message){
        super(message);
    }
}
