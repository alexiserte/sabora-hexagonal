package org.example.Instruction.Exception;

public class ControlInstructionException extends Exception{

    public ControlInstructionException(){};
    public ControlInstructionException(String message){
        super(message);
    }
}
