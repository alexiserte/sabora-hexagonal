package org.example.Instruction.Exception;

public class SoundInstructionException extends Exception{

    public SoundInstructionException(){};
    public SoundInstructionException(String message){
        super(message);
    }
}
