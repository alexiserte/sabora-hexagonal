package org.example.Message;

public enum MessageTypes {
    SEARCH,REGISTER, CONNECTION,DISCONNECTION,START,STOP,ACTION,DATA,TEST
}
